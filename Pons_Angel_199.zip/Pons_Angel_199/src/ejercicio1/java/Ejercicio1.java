/*
 * Descripción: Cálculador básico de nómina
 * Autor: Ángel
 * Fecha: 29/19/25
 */


package ejercicio1.java;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int num_empleado, edad, horas;
		String elegibleParaBono;
		double salarioNeto, salarioBruto, salario, importe;
		boolean jornada;
		final double IRPF = 12;
		
		System.out.println("Cual es tu número de empleado: ");
		num_empleado = teclado.nextInt();
		System.out.println("Cual es tu edad: ");
		edad = teclado.nextInt();
		System.out.println("Cual es tu salario por hora: ");
		salario = teclado.nextDouble();
		System.out.println("Cuantas horas totales has trabajado en la semana: ");
		horas = teclado.nextInt();
		System.out.println("¿Tienes jornada completa?: ");
		jornada = teclado.nextBoolean();
		
		salarioBruto = salario * horas;
		importe = salarioBruto * 0.12;
		salarioNeto = salarioBruto - importe;
		if (jornada=true && horas >= 40) {
			elegibleParaBono =  "Activado";
		} else {elegibleParaBono =  "Anulado";}
		
		System.out.println("El empleado número " + num_empleado + " con " + edad + " años de edad.");
		System.out.println("Tiene un salario a la hora de: " + salario + ".");
		System.out.println("Un salario bruto semanal de: " + salarioBruto+ ".");
		System.out.println("Con el importe de IRPF Retenido de: " + importe + ".");
		System.out.println("Un salario neto de: " + salarioNeto);
		System.out.println("Su estado de Elegilibilidad para el bono es: " + jornada + ".");





		

	}

}
