/*
 * Descripción: Calculador de siglos segun el año que ponga el usuario y si es posterior o anterior al año actual (2025)
 * Autor: Ángel
 * Fecha: 29/19/25
 */


package ejercicio2.java;

import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int año, contador = 0, añosFaltantes;
		String siglo, periodo;
		
		do {
		System.out.println("Introduzca un año (entre 1801-2100): ");
		año = teclado.nextInt();
		if (año < 1801 || año > 2100) {
		contador++;
		} else { contador=3; } }
		
		while (año != -1 || contador < 3);
		
		if (contador >= 3) {
			System.out.println("No es un año válido");
		} else {
		
		if (año < 1901) {
			siglo = "XIX";
			periodo = "Anterior";
			añosFaltantes = 2025 - año;
			System.out.println("El año introducido es " + periodo + " al actual. Han pasado " + año + " años.");
			System.out.println("El año pertenece al siglo " + siglo);
		} else if (año < 2001) {
			siglo = "XX";
			periodo = "Anterior";
			añosFaltantes = 2025 - año;
			System.out.println("El año introducido es " + periodo + " al actual. Han pasado " + año + " años.");
			System.out.println("El año pertenece al siglo " + siglo);
		} else if (año < 2025) {
			siglo = "XXI";
			periodo = "Anterior";
			añosFaltantes = 2025 - año;
			System.out.println("El año introducido es " + periodo + " al actual. Han pasado " + año + " años.");
			System.out.println("El año pertenece al siglo " + siglo);
		} else if (año == 2025) {
			siglo = "XXI";
			periodo = "Actual";
			System.out.println("El año introducido coincide con el actual.");
			System.out.println("El año pertenece al siglo " + siglo);
		} else if (año < 2101) {
			siglo = "XXI";
			periodo = "Posterior";
			añosFaltantes = año - 2025;
			System.out.println("El año introducido es " + periodo + " al actual. Faltan " + año + " años.");
			System.out.println("El año pertenece al siglo " + siglo);
		}
		}
		
		
	}

}

