package Ejemplo_switch;

import java.util.Scanner;

public class ejemplo_switch {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.println("Dime la nota: ");
        int nota = teclado.nextInt();

        String notaTexto;

        switch (nota) {
            case 1:
            case 2:
            case 3:
            case 4:
                notaTexto = "Insuficiente";
                break;
            case 5:
                notaTexto = "Suficiente";
                break;
            case 6:
                notaTexto = "Bien";
                break;
            case 7:
            case 8:
                notaTexto = "Notable";
                break;
            case 9:
            case 10:
                notaTexto = "Sobresaliente";
                break;
            default:
                notaTexto = "Valor no valido";
                break;
        }

        if (notaTexto.equals("Valor no valido")) {
            System.out.println("La nota no es valida");
        } else {
            System.out.println("La nota es: " + notaTexto);
        }

        teclado.close();
    }
}
