/*
 * Descripción: Probando estructuras condicionales
 * Autor: Ángel
 * Fecha: 6/10/25
 */

package Estructuras_condicionales;

import java.util.Scanner;

public class estructuras_condicionales {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int preguntas = 20;
		int notaCuantitativa;
		String notacuantitativa;
		
		int aciertos, fallos;
		System.out.print("Número de preguntas acertadas: ");
		aciertos = teclado.nextInt();
		System.out.println("Número de preguntas falladas: ");
		fallos = teclado.nextInt();
		
		if (preguntas < aciertos + fallos) {
			System.out.print("Datos erroneos");
		
		}
		

	}

}
