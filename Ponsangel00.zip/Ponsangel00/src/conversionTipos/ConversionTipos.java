package conversionTipos;

public class ConversionTipos {

	public static void main(String[] args) {
		byte monederoPequeno = 10;
		int monederoMediano = 10000;
		long monederoGrande = 1000000001;
	
		
		//monederoGrande = monederoMediano; // conversión automática
		//monederoMediano = monederoPequeno;
		
		monederoPequeno = (byte) monederoMediano; // cast
		
		System.out.println("El valor del monedero pequeño es: " + monederoPequeno);
		System.out.println("El valor del monedero mediano es: " + monederoMediano);
		System.out.println("El valor del monedero grande es: " + monederoGrande);
				}

}
