package ejemplo_DoWhile;

import java.util.Scanner;

public class Ejemplo_DoWhile {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int numero, suma = 0, contador = 0;
		
		do {
			System.out.println("Dame un número: (0 para terminar)");
			numero = teclado.nextInt();
			contador = contador +1; 
			suma = suma + numero;
		} while  (numero != 0);
		
		contador = contador -1; // resto 1 al contador para no contar el 0
		System.out.println("La suma es: " + suma + " y la cantidad de números es: " + contador);
	}

}
