package ejemplo_DoWhile;

import java.util.Scanner;

public class Ejemplo_DoWhile2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int contador;
		int inicio;
		int multiplo;
		System.out.println("Introduzca el inicio: ");
		inicio = teclado.nextInt();
		
		int fin;
		System.out.println("Introduzca el fin: ");
		fin = teclado.nextInt();
		
		if (inicio <= fin) { //secuenta creciente
			contador = inicio;
			do {
				if (contador % 3 == 0)
				System.out.println(" " + contador);
				contador = contador + 1;
			} while (contador <= fin);
			
		} else { // secuencia decreciente
			System.out.println("Multiplos de 3 desde " + inicio + "hasta " + fin);
			do {
				contador = inicio;
				System.out.println(" " + contador);
				contador = contador -1;
			} while(contador >= fin);
				
			}
		}
	}
