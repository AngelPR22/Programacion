package ejemplos_while;

import java.util.Scanner;

public class Ejemplo_while2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int inicio, fin;
		System.out.println("Dame el primer número: ");
		inicio = teclado.nextInt();
		System.out.println("Dame el segundo número: ");
		fin = teclado.nextInt();
		
		int contador = inicio;
		System.out.println("La secuencia de numeros es desde " + inicio + " hasta " + fin);

		while (contador <= fin) {
			System.out.print(contador + " ");
			contador = contador +1;
		}
		
	}
}
