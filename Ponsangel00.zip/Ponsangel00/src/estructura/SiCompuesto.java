package estructura;

import java.util.Scanner;

public class SiCompuesto {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Dame un número: ");
		int numero = teclado.nextInt();
		
		if (numero>= 0) { 				// el numero es positivo
			System.out.println("Positivo");
			
			if (numero == 0) { 			// no es positivo pero puede ser cero o negativo
			System.out.println("Cero");
			} else {
				System.out.println("Negativo");
			}
		
		}

	}

}
