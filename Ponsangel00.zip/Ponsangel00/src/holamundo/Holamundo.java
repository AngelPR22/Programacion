/*
 * Descripción: mostrar en consola un texto
 * Autor: Ángel
 * Fecha: 19/09/25
 */
package holamundo;

public class Holamundo {

	public static void main(String[] args) {
		System.out.print("Hola mundo!!!");
		// 

	}

}
