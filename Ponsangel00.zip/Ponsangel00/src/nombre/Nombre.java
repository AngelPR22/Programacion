package nombre;

public class Nombre {

	public static void main(String[] args) {
		System.out.print("Ángel");
	}

}
