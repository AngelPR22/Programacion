/*
 * Descripción: Ejemplos de operadores codicionales
 * Autor: Ángel
 * Fecha: 26/09/25
 */

package operador_condicional;

import java.util.Scanner;

public class Operador_condicional {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		String nombre;
		System.out.println("Dime tu nombre: ");
		nombre = teclado.nextLine();
		int longitud = nombre.length();
		System.out.println("Numero de caracteres: " + longitud);
		
		int edad;
		System.out.print("Dame tu edad: ");
		edad = teclado.nextInt();
		
		String mayorEdad;
		mayorEdad = (edad > 18) ? "Eres mayor de edad": "Eres menor de edad";
		System.out.println(mayorEdad);
		
		String nombreEnMinuscula;
		nombreEnMinuscula = nombre.toLowerCase();
		System.out.println("En minuscula es: " + nombreEnMinuscula);
		
		System.out.println("En mayuscula es: " + nombre.toUpperCase());
		
		boolean esPepe;
		esPepe = nombre.equals("pepe");
		System.out.println(esPepe);

	
	}

}
