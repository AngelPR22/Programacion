package operadores_base;

public class Operadores_base {

	public static void main(String[] args) {
		int dato1, dato2;
		
		dato1 = 5;
		dato2 = 4;
		
		int suma;
		suma = dato1+dato2;
		System.out.println("La suma es:" + suma);

		int dato3, dato4;
		
		dato3 = 10;
		dato4 = 21;
		
		int resta;
		resta = dato3 - dato4;
		System.out.println("La resta es " + resta);
		
		double dato5, dato6;
		
		dato5 = 150;
		dato6 = 11;
		
		double dividir;
		dividir = dato5 / dato6;
		System.out.println("La división es " + dividir);
		
		int dato7, dato8;
		
		dato7 = 1131;
		dato8 = 16;
		
		int resto;
		resto = dato7 % dato8;
		System.out.println("La división es " + resto);
		
		int dato1mas, dato1menos;
		dato1mas = dato1++; // dato1mas = dato1 + 1
		dato1menos = dato1--; // dato1menos = dato1 - 1
		
		System.out.println("Incremental posterior " + ++dato1);
		
		boolean distinto = dato1 != dato2;
		System.out.println (distinto);
	}

}
