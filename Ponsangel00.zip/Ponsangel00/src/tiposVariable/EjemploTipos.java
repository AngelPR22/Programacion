/*
 * Descripción: ejemplos de tipos de variables
 * Autor: Ángel
 * Fecha: 22/09/25
 */
package tiposVariable;

import java.util.Scanner;

public class EjemploTipos {

	public static void main(String[] args) {
		int numAlumnos; // Declaramos la variable numAlumnos
		numAlumnos = 0;
		System.out.println("Valor de la variable: " + numAlumnos);

		numAlumnos = 12; // La variable cambia si ponemos la misma variable
		System.out.println("Valor de la variable: " + numAlumnos);

		double alturaAlumno = 1.75;  // 'double' sirve para ponerlo en decimal
		System.out.println("Valor de la \"variable:\"\n " + alturaAlumno +" cms.");
		
		char letraDni; // 'char' una sola letra
		letraDni = 'a';
		
		String nombreAlumno = "Alberto"; // 'string' cadena de caracteres
		System.out.println("Valor de la variable: " + nombreAlumno);

		final int NUM_MAX_ALUMNOS = 25; // Declaramos una constante
		System.out.println("Valor de la constante: " + NUM_MAX_ALUMNOS);
	
		final String GRUPO = "DAW1";
		System.out.println("Valor del grupo constante: " + GRUPO);
		
		Scanner teclado = new Scanner(System.in);
		
		int edadAlumno;
		System.out.print("Dame tu edad: ");
		edadAlumno = teclado.nextInt();
		System.out.println("La edad es: " + edadAlumno);
		
		teclado.nextLine(); // Despues de pedir valor numérico y antes del valor de los caracteres
		String nomAlumno;
		System.out.println("Dame tu nombre:");
		nomAlumno = teclado.nextLine();
		System.out.println("Tu nombre es: " + nomAlumno);
		
		System.out.println("Dame tu peso:" );
		double pesoAlumno;
		pesoAlumno = teclado.nextDouble();
		System.out.println("Tu peso es:" + pesoAlumno);
	}

}
