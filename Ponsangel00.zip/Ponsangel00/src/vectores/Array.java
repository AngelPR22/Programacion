/*
 * Descripción: Ejemplos de vectores
 * Autor: Ángel
 * Fecha: 17/19/25
 */


package vectores;

public class Array {

	public static void main(String[] args) {
		final int TAMAY10 = 20;
		
		int[] numeros; // Declaramos array enteros
		numeros = new int[TAMAY10]; // Instanciamos el array
		
		for (int posicion = 0 ; posicion < 20; posicion++) {
			numeros[posicion] = 0; // Inicializamos a cero todas las posiciones
		}
		for (int posicion = 0; posicion < 20; posicion++) {
			System.out.println("El valor de la posición es: " + posicion + " es: "+ numeros[posicion]);
		}
	}

}
