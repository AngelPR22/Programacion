/*
 * Descripción: "Se deberá realizar unos cuantos prints para que salgan unos datos en la pantalla".
 * Autor: Ángel
 * Fecha: 24/09/25
 */

package ejercicio2;

public class Ejercicio2 {

	public static void main(String[] args) {

		System.out.println("Desarrollo de Aplicacioneas WEB/Multiplataforma");
		
		System.out.println("1DAW /DAM");
		
		System.out.println("Módulos:");
		
		System.out.println("PRO");
		
		System.out.println("SIS");
	}
}
