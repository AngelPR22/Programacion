/*
 * Descripción: "Definimos el tipo y valor de las variables".
 * Autor: Ángel
 * Fecha: 24/09/25
 */

package ejercicio4;

public class Ejercicio4 {

	public static void main(String[] args) {

		int bytes = 8;
		System.out.println("El valor de la variable de tipo entero (byte) es: " + bytes);
		
		int shorts = 16;
		System.out.println("El valor de la variable de tipo entero (short) es: " + shorts);
		
		int entero = 32;
		System.out.println("El valor de la variable de tipo entero (entero) es: " + entero);
	
		char caracter = 's';
		System.out.println("El valor de la variable de tipo carácter (caracter) es: " + caracter);
		
		double numero_decimal = 4.25;
		System.out.println("El valor de la variable de tipo decimal (numero decimal) es: " + numero_decimal);
		
		float numero_flotante = 32.2f;
		System.out.println("El valor de la variable de tipo flotante (numero flotante) es: " + numero_flotante);
		
		String cadena_caracteres = "angel";
		System.out.println("El valor de la variable de tipo cadena (cadena de caracteres) es: " + cadena_caracteres);
	}

}
