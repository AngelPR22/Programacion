/*
 * Descripción: Crear variables para mostrarlo en pantalla
 * Autor: Ángel
 * Fecha: 26/09/25
 */

package ejercicio3.java;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		int num1 = 1, num2 = 1;
		char char1 = 4, char2 = 6;
		String Cargo = "Alguacil", Nombre = " Ángel";
		
		System.out.println("El valor de las varibles num1 y num2 son: "+ num1 +" y " + num2);
		System.out.println("Bienvenido, " + Cargo + Nombre +". ");

	}

}
