/*
 * Descripción: Se deberá realizar un programa que imprima por pantalla "Este es mi primer programa Java".
 * Autor: Ángel
 * Fecha: 24/09/25
 */

package ejercicio1;

public class Ejercicio1 {

	public static void main(String[] args) {

		System.out.print("Este es mi primer programa java");
	}

}
