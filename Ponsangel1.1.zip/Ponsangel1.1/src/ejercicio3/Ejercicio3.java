/*
 * Descripción: "Empezaremos a usar las variables y mostrar en pantalla el valor de las variables:".
 * Autor: Ángel
 * Fecha: 24/09/25
 */

package ejercicio3;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		int num1 = 0;
		
		int num2 = 0;
		
		double val1 = 1.25; 
		
		double val2 = 4.50; 
		
		String nombre = "Ángel";
		String apellidos = "Pons Ristori";
		
		System.out.println("El valor de la variable num1 es: " + num1 + "\n" + "El valor de la variable num2 es: " + num2);
		
		System.out.println("El valor de la variable val1 es: " + val1 + "\n" + "El valor de la variable val2 es: " + val2);
		
		System.out.println("Mi nombre es " + nombre + " y mis apellidos " + apellidos);

	}

}
