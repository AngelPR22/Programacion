/*
 * Descripción: "Solicitar datos al usuario".
 * Autor: Ángel
 * Fecha: 25/09/25
 */

package ejercicio1.java;

import java.util.Scanner;

public class  Ejercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		String nombre;
		System.out.print("Dame tu nombre: ");
		nombre = teclado.nextLine();
		System.out.println("Tu nombre es: " + nombre);
	
		String apellidos;
		System.out.print("Dime tus apellidos: ");
		apellidos = teclado.nextLine();
		System.out.println("Los apellidos son: " + apellidos);
		
		int edadAlumno;
		System.out.print("Dame tu edad: ");
		edadAlumno = teclado.nextInt();
		System.out.println("La edad es: " + edadAlumno);
		
		teclado.nextLine();
		String direccion;
		System.out.print("Dame tu direccion: ");
		direccion = teclado.nextLine();
		System.out.println("la dirección es: " + direccion);
		
		double altura;
		System.out.print("Dame tu altura: ");
		altura = teclado.nextDouble();
		System.out.println("Tu altura es: " + altura);
		
		double peso;
		System.out.print("Dame tu peso: ");
		peso = teclado.nextDouble();
		System.out.println("Tu peso es: " + peso);
		
	}

}
