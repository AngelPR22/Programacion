/*
 * Descripción: Solicitar datos relativos a un equipo de futbol
 * Autor: Ángel
 * Fecha: 26/09/25
 */

package ejercicio2.java;

import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		String nombre_equipo;
		System.out.println("Dame el nombre del equipo: ");
		nombre_equipo = teclado.nextLine();
		System.out.println("El nombre del equipo es: " + nombre_equipo);

		int año_fundacion;
		System.out.println("Dame el año de fundacion: ");
		año_fundacion = teclado.nextInt();
		System.out.println("El año de fundacion es: " + año_fundacion);

		teclado.nextLine();
		String nombre_estadio;
		System.out.println("Dame el nombre de estadio: ");
		nombre_estadio = teclado.nextLine();
		System.out.println("El nombre de estadio es: " + nombre_estadio);
		
		String nombre_capitan;
		System.out.println("Dame el nombre del capitan: ");
		nombre_capitan = teclado.nextLine();
		System.out.println("El nombre del capitan es: " + nombre_capitan);
		
		
	}

}
