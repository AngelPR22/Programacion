/*
 * Descripción: Crear tipos enumerados
 * Autor: Ángel
 * Fecha: 26/09/25
 */

package ejercicio4.java;

public class Ejercicio4 {
	public enum Tamaño {pequeña, mediana, grande, extragrande};


	public static void main(String[] args) {
		Tamaño tamañoMaximo = Tamaño.extragrande;
		Tamaño tamañoGrande = Tamaño.grande;
		Tamaño tamañoMediana = Tamaño.mediana;
		Tamaño tamañoPequeña = Tamaño.pequeña;

		System.out.println("Este tamaño es " + tamañoMaximo + " porque es el tamaño más grande, para muchas personas.");
		System.out.println("Este tamaño es " + tamañoGrande + " porque es un tamaño grande, ideal para compartir.");
		System.out.println("Este tamaño es " + tamañoMediana + " porque es un tamaño intermedio, ni muy pequeño ni muy grande."); 
		System.out.println("Este tamaño es " + tamañoPequeña + " porque es el tamaño más pequeño disponible.");	
		
	}

}
