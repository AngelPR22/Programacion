/*
 * Descripción: Calculador de salario del usuario
 * Autor: Ángel
 * Fecha: 1/10/25
 */

package ejercicio1.java;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		String nombre;
		System.out.print("Dame tu nombre: ");
		nombre = teclado.nextLine();
		
		String apellidos;
		System.out.print("Dame tus apellidos: ");
		apellidos = teclado.nextLine();
		
		String año_nacimiento;
		System.out.print("Dame tu año de nacimiento (dd/mm/aaaa): ");
		año_nacimiento = teclado.nextLine();
		System.out.println("Tu fecha de nacimiento es: " + año_nacimiento);
		
		double salario_bruto;
		System.out.print("Dame tu salario bruto: ");
		salario_bruto = teclado.nextDouble();
		
		int años_trabajo;
		System.out.print("Dame tus años trabajando en la empresa: ");
		años_trabajo = teclado.nextInt();
		
		double salario_neto = salario_bruto * 0.85;
		System.out.println("Tu salario neto sería: " + salario_neto+"$");
		
		double aumento = salario_neto * 0.02;
		System.out.println("Tu salario se incrementará un: " + aumento + "%");
		teclado.nextLine();
		
		double salario_total = salario_neto + aumento;
		
		// Resultado Final
		
		System.out.print("Estimad@ " +nombre + apellidos+", su salario bruto es " + salario_bruto+"$,"+ "teniendo\r\n"
				+ "en cuenta un IRPF del 15% su salario neto es "+ salario_neto+"$.\r\n"
				+ "Debido a sus " + años_trabajo +" años en la empresa su salario\r\n"
				+ "se incrementará en un 2% por cada año. El aumento es de " + aumento +"$\r\n"
				+ "y el salario total es " + salario_total+"$.");
		
	}

}
