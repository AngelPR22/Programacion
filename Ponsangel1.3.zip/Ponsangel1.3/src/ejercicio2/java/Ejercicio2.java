/*
 * Descripción: Convertidor de euros a pesetas y pesetas a euros.
 * Autor: Ángel
 * Fecha: 1/10/25
 */

package ejercicio2.java;

import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int euros;
		System.out.print("Cuantos euros tienes: ");
		euros = teclado.nextInt();
		double transformadas_pesetas = euros * 166.386;
		System.out.println("Tienes " + transformadas_pesetas +" pesetas");
		
		double pesetas;
		System.out.print("Cuantas pesetas tienes: ");
		pesetas = teclado.nextDouble();
		double transformadas_euros = pesetas / 166.386;
		System.out.println("Tienes " + transformadas_euros + "€");

	}

}
