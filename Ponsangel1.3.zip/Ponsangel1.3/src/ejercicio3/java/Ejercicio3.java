/*
 * Descripción: Intercambiar valores entre variables
 * Autor: Ángel
 * Fecha: 1/10/25
 */

package ejercicio3.java;

import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int num1, num2;
		System.out.print("Dame un valor: ");
		num1 = teclado.nextInt();
		System.out.println("Dame otro valor: ");
		num2 = teclado.nextInt();
		System.out.println("El valor de las dos variables son: "+num1+" y "+num2);
		
		int temp = num1;
		num1 = num2;
		num2 = temp;
		System.out.println("El nuevo valor de las variables son: " +num1+" y "+num2);

	}

}
