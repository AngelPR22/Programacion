/*
 * Descripción: Probando las funciones de clase math
 * Autor: Ángel
 * Fecha: 6/10/25
 */

package ejercicio4.java;

import java.util.Scanner;

public class Ejercicio4 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		double valor;
		System.out.print("Dame un valor: ");
		valor = teclado.nextDouble();
		
		double ceil = Math.ceil(valor);
		double floor = Math.floor(valor);
		long round = Math.round(valor);
		
		 System.out.println("\nResultados:");
	        System.out.println("Número ingresado: " + valor);
	        System.out.println("Math.ceil(" + valor + ") = " + ceil + " → Redondea hacia arriba al entero más cercano.");
	        System.out.println("Math.floor(" + valor + ") = " + floor + "  → Redondea hacia abajo al entero más cercano.");
	        System.out.println("Math.round(" + valor + ") = " + round + "  → Redondea al entero más cercano según la parte decimal.");

	}

}
