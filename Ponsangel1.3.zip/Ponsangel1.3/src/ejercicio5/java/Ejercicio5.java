/*
 * Descripción: Calcular numeros que pida el usuario con funciones de la clase math
 * Autor: Ángel
 * Fecha: 6/10/25
 */

package ejercicio5.java;

import java.util.Scanner;

public class Ejercicio5 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		double valor1, valor2;
		System.out.print("Dame un valor: ");
		valor1 = teclado.nextDouble();
		System.out.println("Dame otro valor: ");
		valor2 = teclado.nextDouble();
		
		double min = Math.min(valor1, valor2);
		System.out.println("El valor mas menos de los dos sería: " + min);
		
		double pow = Math.pow(valor1, valor2);
		System.out.println("El valor del primer numero elevado al segudo es: " + pow);
		
		double sqrt = Math.sqrt(valor1);
		System.out.println("La raiz cuadrada del primer valor es: " + sqrt);
		
		double random = Math.random() * valor2;
		System.out.println("Un valor random del segundo número sería: " + random);
	
	}

}
