/*
 * Descripción: Comprobar si un número es mayor, menos o igual a su segundo número
 * Autor: Ángel
 * Fecha: 6/10/25
 */

package Ejercicio1.java;

import java.util.Scanner;

public class ejercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		int num1, num2;
		System.out.print("Dame el primer valor: ");
		num1 = teclado.nextInt();
		System.out.println("Dame el segundo valor: ");
		num2 = teclado.nextInt();

		if (num1 > num2) 
			System.out.println("El primer número es mayor que el segundo");
		else if (num1 < num2) 
			System.out.println("El primero número es menor que el segundo");
			else System.out.println("El primero número es igual al segundo");
			
		
	}

}
