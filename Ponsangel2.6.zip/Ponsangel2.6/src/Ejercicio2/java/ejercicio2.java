/*
 * Descripción: Admision a la matriculación de curso cumpliendo los requisitos mínimos
 * Autor: Ángel
 * Fecha: 6/10/25
 */


package Ejercicio2.java;

import java.util.Scanner;

public class ejercicio2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		String nombre;
		System.out.print("Dame tu nombre: ");
		nombre = teclado.nextLine();
		
		int edad;
		System.out.println("Dame tu edad: ");
		edad = teclado.nextInt();
		
		double nota;
		System.out.println("Dame tu nota académica: ");
		nota = teclado.nextDouble();
		
		if (edad > 17) {
			if (nota >= 7)
				System.out.println(nombre + ", " + "usted ha sido admitido en el curso, cumple las condiciones requeridas");
			else 
				System.out.println(nombre + ", " + "lo sentimos, no ha sido admitido en el curso ya que no cumple los requisitos mínimos");
		}
		
	}

}
