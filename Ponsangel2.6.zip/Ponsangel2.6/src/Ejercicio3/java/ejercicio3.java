/*
 * Descripción: Admision a la matriculación de curso por edad 
 * Autor: Ángel
 * Fecha: 9/10/25
 */


package Ejercicio3.java;

import java.util.Scanner;

public class ejercicio3 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int edad;
		System.out.print("Cual es tu edad: ");
		edad = teclado.nextInt();
		teclado.nextLine();
		
		if (edad <= 17) {
			System.out.println("Lo sentimos, no ha sido admitido en el curso ya que no cumple los requisitos mínimos");
		} else {
			String nombre;
			System.out.println("Dame tu nombre: ");
			nombre = teclado.nextLine();
			String apellidos;
			System.out.println("Dame tus apellidos: ");
			apellidos = teclado.nextLine();
			System.out.println("Nombre: " + nombre + "\nApellidos: "+ apellidos + "\nEdad: " + edad + "\n\nUsted ha sido admitido");
		}
	}

}
