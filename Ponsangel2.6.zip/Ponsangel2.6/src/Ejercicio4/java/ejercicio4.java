/*
 * Descripción: Calculador de importe gastado en un mes para entregar cupones de descuento. 
 * Autor: Ángel
 * Fecha: 9/10/25
 */


package Ejercicio4.java;

import java.util.Scanner;

public class ejercicio4 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		String nombre, apellidos;
		System.out.println("Cual es tu nombre: ");
		nombre = teclado.nextLine();
		System.out.println("Cuales son tus apellidos: ");
		apellidos = teclado.nextLine();
		
		int media, suma, importe1, importe2, importe3, importe4;
		System.out.println("Cual fue tu primer importe gastado: ");
		importe1 = teclado.nextInt();
		System.out.println("Cual fue tu segundo importe gastado: ");
		importe2 = teclado.nextInt();
		System.out.println("Cual fue tu tercero gastado: ");
		importe3 = teclado.nextInt();
		System.out.println("Cual fue tu cuarto importe gastado: ");
		importe4 = teclado.nextInt();
		teclado.nextLine();
		
		suma = importe1 + importe2 + importe3 + importe4;
		media = suma/4;
		
		if (suma >= 300) {
			System.out.println("Nombre: " + nombre + "\nApellidos: " + apellidos + "\nImporte Gastado1: " + importe1 + "\nImporte Gastado2: " + importe2 + "\nImporte Gastado3: " + importe3 + "\nImporte Gastado4: " + importe4 + "\n\nImporte Medio: " + media + "\n\nEnhorabuena!!! Sus compras han alcanzado los 300 euros este mes, dispone de descuento.");
		} else {
			System.out.println("Nombre: " + nombre + "\nApellidos: " + apellidos + "\nImporte Gastado1: " + importe1 + "\nImporte Gastado2: " + importe2 + "\nImporte Gastado3: " + importe3 + "\nImporte Gastado4: " + importe4 + "\n\nImporte Medio: " + media + "\n\nLo sentimos pero sus compras no han alcanzado los 300 euros este mes, no dispone de descuento.");
		}
	}

}
