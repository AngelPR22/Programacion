/*
 * Descripción: Calculador de notas en formato palabra
 * Autor: Ángel
 * Fecha: 10/10/25
 */


package Ejercicio5.java;

import java.util.Scanner;

public class Ejercicio5 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		String nombre, apellidos, ciclo;
		System.out.print("Cual es tu nombre: ");
		nombre = teclado.nextLine();
		System.out.println("Cuales son tus apellidos: ");
		apellidos = teclado.nextLine();
		System.out.println("Cual es tu ciclo formativo: ");
		ciclo = teclado.nextLine();
		
		int nota;
		System.out.println("Cual es tu nota academica: ");
		nota = teclado.nextInt();
		teclado.nextLine();
		
		if (nota < 5) {
			System.out.println("Nombre: " + nombre + "\nApellidos: " + apellidos + "\nCiclo formativo: " + ciclo + "\nNota academica: " + nota + " (Insuficiente)");
		} else if (nota < 6) {
			System.out.println("Nombre: " + nombre + "\nApellidos: " + apellidos + "\nCiclo formativo: " + ciclo + "\nNota academica: " + nota + " (Suficiente)");
		} else if (nota < 7) {
			System.out.println("Nombre: " + nombre + "\nApellidos: " + apellidos + "\nCiclo formativo: " + ciclo + "\nNota academica: " + nota + " (Bien)");
		} else if (nota < 9) {
			System.out.println("Nombre: " + nombre + "\nApellidos: " + apellidos + "\nCiclo formativo: " + ciclo + "\nNota academica: " + nota + " (Notable)");
		} else {
			System.out.println("Nombre: " + nombre + "\nApellidos: " + apellidos + "\nCiclo formativo: " + ciclo + "\nNota academica: " + nota + " (Sobresaliente)");
		}
		
	}

}
