/*
 * Descripción: Creador de entrevistas 
 * Autor: Ángel
 * Fecha: 16/10/25
 */

package ejercicio1.java;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		String nombre, apellidos;
		int edad, años_experiencia, proyectos;
		double salario;
		
		System.out.println("Cual es tu nombre: ");
		nombre = teclado.nextLine();
		System.out.println("Cuales son tus apellidos: ");
		apellidos = teclado.nextLine();
		System.out.println("Cual es tu edad: ");
		edad = teclado.nextInt();
		System.out.println("Cual es tu salario: ");
		salario = teclado.nextDouble();
		
		if (salario > 30000 || edad > 45) {
			System.out.println("Lo sentimos no cumple nuestro perfil");
			return;
		}
			System.out.println("Cuales son tus años de experiencia: ");
			años_experiencia = teclado.nextInt();
			System.out.println("Cuales son tus proyectos trabajados anteriormente: ");
			proyectos = teclado.nextInt();
		
		if (años_experiencia > 2 && proyectos > 3) {
			System.out.println("Enhorabuena. Ha sido contratado");
		} else {
			System.out.println("Lo sentimos pero no cumple nuestro perfil");
		}
	}
  
}
