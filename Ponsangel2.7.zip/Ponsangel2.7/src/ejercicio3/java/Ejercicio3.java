/*
 * Descripción: Calificador de notas mediante el uso de un switch
 * Autor: Ángel
 * Fecha: 16/10/25
 */

package ejercicio3.java;

import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int nota;
		System.out.print("Cual es tu nota: ");
		nota = teclado.nextInt();
		
		String notaTexto;
		
		switch (nota) {
		
		case 1:
		case 2:
		case 3:
		case 4:
			notaTexto = "Insuficiente";
			break;
		case 5:
			notaTexto = "Suficiente";
			break;
		case 6:
			notaTexto = "Bien";
			break;
		case 7:
		case 8:
			notaTexto = "Notable";
			break;
		case 9:
		case 10:
			notaTexto = "Sobresaliente";
			break;
		default:
			notaTexto = "Valor no valido";
		}
		
		if (notaTexto.equals("Valor no valido")) {
			System.out.println("El valor es erroneo");
		} else {
			System.out.println("La nota es " + notaTexto);
		}

	}

}
