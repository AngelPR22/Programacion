/*
 * Descripción: Calificador de notas medias para acceder a cursos superiores
 * Autor: Ángel
 * Fecha: 16/10/25
 */

package ejercicio4.java;

import java.util.Scanner;
import java.lang.Math;

public class Ejercicio4 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		double biologia, ingles, mates, historia;
		
		System.out.println("Cual es tu nota de biologia: ");
		biologia = teclado.nextDouble();
		System.out.println("Cual es tu nota de ingles: ");
		ingles = teclado.nextDouble();
		System.out.println("Cual es tu nota de mates: ");
		mates = teclado.nextDouble();
		System.out.println("Cual es tu nota de historia: ");
		historia = teclado.nextDouble();
		
		double media = (biologia + ingles + mates + historia)/4;
		System.out.println("Tu nota media es: " + media);
		System.out.println("Tu nota media redondeada hacia arriba es: " + Math.ceil(media));
		System.out.println("Tu nota media redondeada hacia abajo es: " + Math.floor(media));

		if (media > 8) {
			System.out.println("Puedes accedr a estudios superiores");
		} else {
			System.out.println("Tu nota media obtenia no es suficiente para acceder a los estudios que deseaba");

		}
	}

}
