/*
 * Descripción: Calculadora de operaciones básicas
 * Autor: Ángel
 * Fecha: 16/10/25
 */

package ejercicio5.java;

import java.util.Scanner;

public class Ejercicio5 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int num1, num2;
		System.out.println("Dame un valor: ");
		num1 = teclado.nextInt();
		teclado.nextLine();
		System.out.println("Dame otro valor: ");
		num2 = teclado.nextInt();
		teclado.nextLine();

		int suma = num1 + num2, resta = num1 - num2, multiplicar = num1 * num2, dividir = num1 / num2;
		int numero;
		
		System.out.println("Indique la operación que quiere realizar(Inserte un número): \n\n(1) Suma\n(2) Resta\n(3) Multiplicación\r\n(4) División");
		numero = teclado.nextInt();
		
		if (numero==1) {
			System.out.println("El resultado es: " + suma);
		} else if (numero==2) {
			System.out.println("El resultado es: " + resta);
		} else if (numero==3) {
			System.out.println("El resultado es: " + multiplicar);
		} else if (numero==4) {
			System.out.println("El resultado es: " + dividir);
		} else {
			System.out.println("Has insertado un número erroneo");
		}

	}

}
