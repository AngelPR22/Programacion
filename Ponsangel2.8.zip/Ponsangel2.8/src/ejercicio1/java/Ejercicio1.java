/*
 * Descripción: Bucle del número 1 al 100
 * Autor: Ángel
 * Fecha: 17/10/25
 */


package ejercicio1.java;

public class Ejercicio1 {

	public static void main(String[] args) {
		int num = 1, suma = 1;
				
		while (num<101) {
			System.out.println(num);
			num = num + suma;
		}
	}

}
