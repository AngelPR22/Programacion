/*
 * Descripción: Bucle del número 1 al 100 usando do-while
 * Autor: Ángel
 * Fecha: 17/10/25
 */

package ejercicio2.java;

public class Ejercicio2 {

	public static void main(String[] args) {
		int suma = 1, num = 1;
		
		do {
			System.out.println(num);
			num = num + suma;
		} while (num < 101);

	}

}
