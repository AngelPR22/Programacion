/*
 * Descripción: Bucle del número 100 al 1 usando do-while
 * Autor: Ángel
 * Fecha: 20/10/25
 */

package ejercicio3.java;

public class Ejercicio3 {

	public static void main(String[] args) {
		int num = 100, resta = 1;
		
		do {
			System.out.println(num);
			num = num - resta;
		} while ( num != 0);
		
	}

}
