/*
 * Descripción: Calculador de cantidad de números mayores de 0 introducidos así como la media de los mismos mediante el bucle while.
 * Autor: Ángel
 * Fecha: 20/10/25
 */


package ejercicio4.java;

import java.util.Scanner;

public class Ejercicio4 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		int num, contador = 0;
		double media, suma = 0;

		
		System.out.println("Dame un valor: ");
		num = teclado.nextInt();
		
		while (num != 0) {
			if (num > 0) {
				suma = suma + num;
				contador++;
			}
			System.out.println("Dame un valor (Si se pone 0 se rompe el bucle): ");
			num = teclado.nextInt();
		}
		if (contador > 0) {
			media = suma/contador;
		System.out.println("La cantidad de números mayores de 0 son: " + contador);
		System.out.println("La media de todos estos son: " + media);
		} else {  System.out.println("No hay numeros mayor de 0"); }

	}
		
}
