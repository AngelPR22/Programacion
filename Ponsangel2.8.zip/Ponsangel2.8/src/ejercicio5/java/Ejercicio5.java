/*
 * Descripción: Pedir 10 numeros y mostrar la media de numeros positivos, negativos y la cantidad de ceros.
 * Autor: Ángel
 * Fecha: 20/10/25
 */

package ejercicio5.java;

import java.util.Scanner;

public class Ejercicio5 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int num, contador = 0, contador_ceros = 0, contador_positivos = 0, contador_negativos = 0; 
		double positivos = 0, negativos = 0, media_positivos, media_negativos;
		
		do { 
			System.out.println("Dame diez valores: ");
			num = teclado.nextInt();
			contador++; 
			if (num < 0) {
				negativos = negativos + num;
				contador_negativos++;
			} else if (num > 0) {
				positivos = positivos - num;
				contador_positivos++;
			} else { 
				contador_ceros++;
			}		
		} while (contador != 10); 
		
		media_positivos = positivos/contador_positivos;
		media_negativos = negativos/contador_negativos;

		System.out.println("La media de los numeros positivos fueron: " + media_positivos);
		System.out.println("La media de los numeros negativs fueron: " + media_negativos);
		System.out.println("La cantidad de ceros fueron: " + contador_ceros);

		
	}
}
