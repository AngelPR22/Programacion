/*
 * Descripción: Mostrar el cuadrado de un numero en bucle hasta introducir negativo.
 * Autor: Ángel
 * Fecha: 20/10/25
 */

package ejercicio6.java;

import java.util.Scanner;

public class Ejercicio6 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int num, cuadrado;
		
		do {
			
			System.out.println("Dame un valor (Si es negativo se terminara): ");
			num = teclado.nextInt();
			cuadrado = num * num;
			if (num >= 0) {
			System.out.println("El cuadrado de este número es: " + cuadrado); }
			else {System.out.println("El bucle se ha cerrado"); }
		} while (num >= 0);
		

	}

}
