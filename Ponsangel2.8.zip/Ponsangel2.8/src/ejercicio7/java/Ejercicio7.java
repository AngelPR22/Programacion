/*
 * Descripción: Juego de adivinar el numero entero
 * Autor: Ángel
 * Fecha: 20/10/25
 */

package ejercicio7.java;

import java.util.Scanner;
import java.util.Random;

public class Ejercicio7 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int intento;
		int numeroSecreto = (int)(Math.random() * 101);
		
		do {
		System.out.println("Adivina el numero secreto del 1 al 50: ");
		intento = teclado.nextInt();
		if (numeroSecreto < intento) {
			System.out.println("Menor");
		} else if (numeroSecreto > intento)	{
			System.out.println("Mayor");
		}
		} while (intento != numeroSecreto);
		System.out.println("Adivinastes el numero secreto!!! Era el número " + numeroSecreto);	
	}
}
