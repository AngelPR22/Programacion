/*
 * Descripción: Calculador de distancia
 * Autor: Ángel
 * Fecha: 22/10/25
 */


package ejercicio8.java;

import java.util.Scanner;

public class Ejercicio8 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		String nombre, apellidos, ciudad, ciudad_larga = "";
		int edad, num_rutas, num_participantes, contador = 0;
		double distancia_ruta, distancia, distancia_larga = 0, media_rutas = 0;
		
		System.out.println("Cual es tu nombre: ");
		nombre = teclado.nextLine();
		
		System.out.println("Cuales son tus apellidos: ");
		apellidos = teclado.nextLine();
		
		do { 
			System.out.println("Cual es tu edad: ");
			edad = teclado.nextInt();
			if (edad < 17 || edad > 45) {
				System.out.println("Esa edad no es correcta"); }
		} while (edad < 17 || edad > 45);

		System.out.println("Cuantas rutas has realizado: ");
		num_rutas = teclado.nextInt();
		
		System.out.println("Cuanta es la distancia de tu última ruta (en metros): ");
		distancia_ruta = teclado.nextDouble();
		
		do {
			System.out.println("Cuanta es la distancia de una de tus caminatas: ");
			distancia = teclado.nextDouble();
			System.out.println("Cuantos participantes hubo: ");
			num_participantes = teclado.nextInt();
			teclado.nextLine();
			System.out.println("En cual ciudad fue: ");
			ciudad = teclado.nextLine();
			media_rutas = distancia + media_rutas;
			if (distancia_larga < distancia) {
				distancia_larga = distancia;
				ciudad_larga = ciudad; }
			contador++;
		} while (contador != 5);
		
		media_rutas = media_rutas/contador;
		
		System.out.println("Nombre: " + nombre + "\nEdad: " + edad + "\nNúmero de rutas realizadas: " + num_rutas + "\nDistancia media (5 últimas rutas): " + media_rutas + "\nDistancia mas larga de las últimas 5 rutas " + distancia_larga + "\nCiudad de la ruta mas larga: " + ciudad_larga);
	}

}
