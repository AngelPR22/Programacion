/*
 * Descripción: Bucle mostrar los primeros 20 numeros naturales
 * Autor: Ángel
 * Fecha: 23/10/25
 */

package ejercicio1;

public class Ejercicio1 {

	public static void main(String[] args) {
		
		int numero; 
		for (numero=1; numero<=20; numero++) {
		    System.out.print (" " + numero);
		}
	}

}
