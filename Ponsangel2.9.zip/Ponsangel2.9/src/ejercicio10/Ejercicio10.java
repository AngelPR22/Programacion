/*
 * Descripción: Lector de secuencia de notas del 0 al 10 que termine con el valor -1, decir si hubo 10 o no.
 * Autor: Ángel
 * Fecha: 27/10/25
 */

package ejercicio10;

import java.util.Scanner;

public class Ejercicio10 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int num, valor_diez, contador = 0;
		
		do {
			System.out.println("Dame notas del 0 al 10 (Si pones -1 finaliza): ");
			num = teclado.nextInt();
			if (num < -1) {
				System.out.println("\nVALOR INCORRECTO, VUELVA A INTENTAR\n");
			} else if (num > 10) {
				System.out.println("\nVALOR INCORRECTO, VUELVA A INTENTAR\n");
			} else if (num == 10) {
				contador++;
			}
		} while (num != -1);
		
		if (contador > 0) {
			System.out.println("\nHa habido alguna nota con valor 10");			
		} else { System.out.println("\nNo ha habido niguna nota con valor 10"); }
	}
}
