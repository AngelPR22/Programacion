/*
 * Descripción: Suma independiente de pares e impares entre los números 100 y 200, mostrar sumas de ambas.
 * Autor: Ángel
 * Fecha: 27/10/25
 */

package ejercicio11;

public class Ejercicio11 {

	public static void main(String[] args) {
		
		int num, suma_par = 0, suma_impar = 0;
		
		for (num = 100; num <= 200; num++) {
			if (num % 2 == 0 ) {
				suma_par = num + suma_par;
			} else if (num % 2 != 0) {
				suma_impar = num + suma_impar;
			}
		}
		System.out.println("Las sumas pares de los números 100 al 200 son: " + suma_par);
		System.out.println("Las sumas impares de los números 100 al 200 son: " + suma_impar);
	}

}
