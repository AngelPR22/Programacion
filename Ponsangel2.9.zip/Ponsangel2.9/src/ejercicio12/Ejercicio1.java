package ejercicio12;

public class Ejercicio1 {

	public static void main(String[] args) {
		
		int num = 2, valor;
		
		valor = 5 ^ 3;
		System.out.print(valor);
	} 
}
