/*
 * Descripción: Contador de numeros pares en 1 y 200 sumando de dos en dos
 * Autor: Ángel
 * Fecha: 23/10/25
 */


package ejercicio2;

public class Ejercicio2 {

	public static void main(String[] args) {
		
		int num, contador =0;
		for (num=0; num<=200; num = num + 2) {
			contador = num;
			System.out.print(" " + contador);	
		}	
	}
}
