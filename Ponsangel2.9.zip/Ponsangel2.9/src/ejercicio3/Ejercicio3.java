/*
 * Descripción: Contador de numeros pares en 1 y 200 sumando de 1 en 1
 * Autor: Ángel
 * Fecha: 23/10/25
 */


package ejercicio3;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		int num, contador =0;
		for (num=0; num<=200; num++) {
			contador = num * 2;
			System.out.print(" " + contador);
		}
	}
}
