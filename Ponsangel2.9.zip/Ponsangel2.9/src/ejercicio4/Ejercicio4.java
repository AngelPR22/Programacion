/*
 * Descripción: Contador de numeros del 1 hasta N
 * Autor: Ángel
 * Fecha: 23/10/25
 */



package ejercicio4;

import java.util.Scanner;

public class Ejercicio4 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int num, pedir = 0;
		
		while (pedir <=1) {
			System.out.println("Dame un valor positivo mayor a 1: ");
			pedir = teclado.nextInt(); }
		
		
		for (num=1; num<=pedir; num++) {
			System.out.print(" " + num);
		}
	}

}
