/*
 * Descripción: Leer numero positivo N y calcular su factorial N!
 * Autor: Ángel
 * Fecha: 23/10/25
 */

package ejercicio5;

import java.util.Scanner;

public class Ejercicio5 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int num = -1, factorial = 1, calcular;
		
		while (num<0) {
			System.out.println("Dame un valor positivo: ");
			num = teclado.nextInt();
		}
		for (calcular = 1; calcular <= num; calcular++) {
			factorial *= calcular;
		}
		System.out.print("El factorial de " + num + " es " + factorial);

	}

}
