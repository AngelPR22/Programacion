/*
 * Descripción: Mostrar 100 números no nulos y luego muestre si ha leido algún negativo o no.
 * Autor: Ángel
 * Fecha: 24/10/25
 */

package ejercicio6;

import java.util.Scanner;

public class Ejercicio6 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int num, negativos = 0, contador = 0;
		
		do {
			System.out.println("Dame un número no nulo: ");
			num = teclado.nextInt();
			if (num > 0) {
				contador++;
			} else if (num < 0) {
				negativos--;
				contador++;
			} else { System.out.println("ERROR NÚMERO NULO, VUELVE A INTENTAR"); }
		} while (contador<5);
		
		if (negativos < 0) {
		System.out.println("Se ha leido un o varios números negativos ");
		} else { System.out.println("No se ha leido ningún número negativo "); }
	}
}

