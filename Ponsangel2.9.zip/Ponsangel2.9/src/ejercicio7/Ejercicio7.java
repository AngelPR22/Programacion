/*
 * Descripción: Leer 100 números no nulos y mostrar cuantos positivos y negativos hay
 * Autor: Ángel
 * Fecha: 23/10/25
 */

package ejercicio7;

import java.util.Scanner;

public class Ejercicio7 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int num, positivos = 0, negativos = 0, contador = 0;
		
		do {
			System.out.println("Dame un valor no nulo: ");
			num = teclado.nextInt();
			if (num > 0) {
				positivos++;
				contador++;
			} else if (num < 0) {
				negativos++;
				contador++;
			} else { System.out.println("ERROR NÚMERO NULO, VUELVE A INTENTAR"); }
		} while (contador<100);

		System.out.println("He leido " + positivos + " positivos ");
		System.out.println("He leido " + negativos + " negativos ");		
	}		
}


