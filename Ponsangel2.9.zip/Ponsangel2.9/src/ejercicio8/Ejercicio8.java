/*
 * Descripción: "Secuencias de numeros no nulos hasta mostrar un cero y mostrar si ha leido algún negativo, cuantos positivos y negativos.".
 * Autor: Ángel
 * Fecha: 24/09/25
 */

package ejercicio8;

import java.util.Scanner;

public class Ejercicio8 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int num, positivo = 0, negativo = 0, contador = 0;
		
		do {
			System.out.println("Dame varios valores (Si pones un 0 se termina): ");
			num = teclado.nextInt();
			if (num < 0) {
				negativo++;
				contador++;
			} else if (num > 0) {
				positivo++;
			}
		} while (num != 0);
		
		if (contador > 0) {
		System.out.println("\nSe ha leido algún número negativo");
		} else { System.out.println("\nNo se ha leido ningún número negativo"); }
		
		System.out.println("\nSe ha leido " + positivo + " números positivos");
		System.out.println("Se ha leido " + negativo + " números negativos");
	}

}
