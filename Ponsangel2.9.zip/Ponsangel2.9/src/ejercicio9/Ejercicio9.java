/*
 * Descripción: "Calculador de la suma y el producto de los 10 primeros números naturales".
 * Autor: Ángel
 * Fecha: 24/09/25
 */

package ejercicio9;

public class Ejercicio9 {

	public static void main(String[] args) {
		
		int num, suma = 0, producto = 1;
		
		for (num = 1; num <=10; num++) {
			suma = num + suma;
			producto = num * producto;
		}
		System.out.print("La suma de los primeros diez números son: " + suma + "\nEl producto de los primeros diez números son: " + producto);
		
		
		
	}

}
