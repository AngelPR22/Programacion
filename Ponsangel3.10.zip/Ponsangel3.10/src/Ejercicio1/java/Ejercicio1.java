/*
 * Descripción: Pedir 10 números reales por teclado, almacenandolos en un array, y mostrando todos sus valores.
 * Autor: Ángel
 * Fecha: 30/10/25
 */

package Ejercicio1.java;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int tamaño = 10;
		Double[] numeros = new Double[tamaño];
		
		System.out.println("Introduce " + tamaño + " números: ");

		
		for (int i = 0; i < tamaño; i++) {
			System.out.println("Número en poción " + i + ":");
			numeros[i] = teclado.nextDouble();
		}
		
		for (int i = 0; i < tamaño; i++) {
		System.out.println("Los 10 números reales introducidos son: " + numeros[i]);
		}

	}

}
