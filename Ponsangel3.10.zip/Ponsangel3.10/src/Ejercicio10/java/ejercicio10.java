/*
 * Descripción: Calculadora de altura (en metro) de personas, pedir valor N y almacenarlo en array, luego mostrar la altura media, máxima y mínima y cuantas personas miden por encima y por debajo de la media.
 * Autor: Ángel
 * Fecha: 10/11/25
 */

package Ejercicio10.java;

import java.util.Scanner;

public class ejercicio10 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int contador_encima = 0, contador_debajo = 0;
		double N, media = 0, maximo = 0, minimo = 1000;
		double[] altura = new double[10];
		
		
		System.out.println("QUIERO LA ALTURA DE 10 PERSONAS");
		for (int i = 0; i < 10; i++) {
			System.out.println("Dame una altura: ");
			N = teclado.nextDouble();
			altura[i] = N;
		}
		
		for (int i = 0; i < 10; i++) {
			media += altura[i];
			if (altura[i] > maximo) {
				maximo = altura[i];
			} else if (altura[i] < minimo) {
				minimo = altura[i];
			}
		}

		media = media / 10;
		
		for (int i = 0; i < 10; i++) {
		if (media < altura[i]) {
			contador_encima++;
		} else if (media > altura[i]) {
			contador_debajo++;
		}
		}
		System.out.println("El resultado de todo estos calculos son los siguientes: \nLa altura media es: " + media + "\nLa altura máxima es: " + maximo + "\nLa altura mínima es: " + minimo + "\nEl numero de personas que mide por encima de la media son: " + contador_encima + "\nEl número de personas que miden por debajo de la media son: " + contador_debajo);
	}
}
