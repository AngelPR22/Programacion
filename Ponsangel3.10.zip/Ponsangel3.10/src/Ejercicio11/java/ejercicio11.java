/*
 * Descripción: Crear dos arrays enteros de tamaño 100, en primer array introducira todos los valores del 1 al 100 y en segundo copiar los valores del primero al segundo de orden inverso.
 * Autor: Ángel
 * Fecha: 10/11/25
 */

package Ejercicio11.java;

public class ejercicio11 {

	public static void main(String[] args) {
		
		int[] valores = new int [100], valoresInvertidos = new int [100];

		
		System.out.println("Los números del 1 al 100 del primer array"); 
		
		for (int i = 0; i < 100; i++) {
			valores[i] = i + 1;
			System.out.print(valores[i] + " ");
		}
		
		System.out.println("\nLos números del 100 al 1 del segundo array"); 
		
		for (int i = 0; i < 100; i++) {
			valoresInvertidos[i] = valores[valores.length - 1 - i];
			System.out.print(valoresInvertidos[i] + " ");
		}
		

	}
}
