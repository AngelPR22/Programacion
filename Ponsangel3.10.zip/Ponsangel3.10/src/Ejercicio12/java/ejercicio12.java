package Ejercicio12.java;

public class ejercicio12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
