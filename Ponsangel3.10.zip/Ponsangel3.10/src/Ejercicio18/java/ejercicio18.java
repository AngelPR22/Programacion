package Ejercicio18.java;

public class ejercicio18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
