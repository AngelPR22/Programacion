package Ejercicio19.java;

public class ejercicio19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
