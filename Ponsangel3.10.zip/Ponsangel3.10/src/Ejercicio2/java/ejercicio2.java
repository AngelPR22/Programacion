/*
 * Descripción: Pedir 10 números reales por teclado, almacenar valores y sumarlos.
 * Autor: Ángel
 * Fecha: 30/10/25
 */

package Ejercicio2.java;

import java.util.Scanner;

public class ejercicio2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in); 
		
		int tamaño = 10;
		double suma = 0;
		Double[] num = new Double[tamaño];
		
		System.out.println("Dame " + tamaño + " números");
		
		for(int i = 0; i < tamaño; i++) {
			System.out.println("Dame el número en la posición " + i + ":");
			num[i] = teclado.nextDouble();
			suma = suma + num[i];
		}
		
		System.out.println("\nLa suma de todos los valores es: " + suma);
			
		
	}

}
