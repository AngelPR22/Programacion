/*
 * Descripción: Pedir 10 números reales por teclado, almacenar valores y mostrar su maximo y minimo.
 * Autor: Ángel
 * Fecha: 3/11/25
 */

package Ejercicio3.java;

import java.util.Scanner;

public class ejercicio3 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int tamaño = 10;
		Double[] num = new Double[tamaño];
	

		System.out.println("Dame 10 números reales ");
		
		for (int i = 0; i < tamaño; i++) {
			System.out.println("Dame el numero de la posición " + i + ": ");
			num[i] = teclado.nextDouble();
		}
		
		Double maximo = num[0];
		Double minimo = num[0];
		
		for (int i = 0; i < tamaño; i++) {
			if (num[i] > maximo) {
				maximo = num[i];
			}
			if (num[i] < minimo) {
				minimo = num[i];
			}
		}
		System.out.println("El número máximo es " + maximo + " y el minimo es " + minimo);
	}

}
