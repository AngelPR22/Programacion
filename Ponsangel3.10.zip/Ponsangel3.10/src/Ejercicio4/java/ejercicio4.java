/*
 * Descripción: Pedir 20 números reales por teclado, almacenar valores y mostrar la suma de todos sus valores postivos y negativos.
 * Autor: Ángel
 * Fecha: 3/11/25
 */

package Ejercicio4.java;

import java.util.Scanner;

public class ejercicio4 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		Double[] num = new Double[20];
		double suma = 0;
		double suma_negativo = 0;

		System.out.println("Dame 20 números reales: ");
		
		for (int i = 0; i < 20; i++) {
			System.out.println("Dame el número de la posición " + i + ": ");
			num[i] = teclado.nextDouble();
		}
		
		for (int i = 0; i < 20; i++) {
			if (num[i] >= 0) {
				suma = suma + num[i];
			} else {
				suma_negativo = suma_negativo - num[i];
			}
		}
		System.out.println("La suma de positivos son : " + suma + " y la de negativos son: -" + suma_negativo);
	}
}
