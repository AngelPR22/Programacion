/*
 * Descripción: Pedir 20 números reales por teclado, almacenar valores y mostrar la suma de todos sus valores postivos y negativos.
 * Autor: Ángel
 * Fecha: 3/11/25
 */

package Ejercicio5.java;

import java.util.Scanner;

public class ejercicio5 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		double suma = 0, media;
		Double[] num = new Double[20];
		
		System.out.println("Dame 20 numeros");
		
		for (int i = 0; i < 20; i++) {
			System.out.println("Dame el número en la posición " + i + ": ");
			num[i] = teclado.nextDouble();
		}
		
		for (int i = 0; i < 20; i++) {
			suma = suma + num[i];
		}
		
		media = suma / 20;
		System.out.println("La media de los 20 números son : " + media);

	}

}
