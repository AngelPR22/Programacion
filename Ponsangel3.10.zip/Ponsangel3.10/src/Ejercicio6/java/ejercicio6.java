/*
 * Descripción: Pedir dos valores enteros, crear array de tamaño N y escriba M en todas sus posiciones y los muestre.
 * Autor: Ángel
 * Fecha: 5/11/25
 */


package Ejercicio6.java;

import java.util.Scanner;

public class ejercicio6 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
        System.out.print("Introduce el tamaño del array (N): ");
        int N = teclado.nextInt();

        System.out.print("Introduce el valor a repetir (M): ");
        int M = teclado.nextInt();

        // Crear el array de tamaño N
        int[] array = new int[N];

        // Llenar el array con el valor M
        for (int i = 0; i < N; i++) {
            array[i] = M;
        }

        // Mostrar el array por pantalla
        System.out.println("El array resultante es:");
        for (int i = 0; i < N; i++) {
            System.out.print(array[i] + " ");
        }
    }
}