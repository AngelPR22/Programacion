/*
 * Descripción: Pedir dos valores enteros, crear array de tamaño N y escriba M en todas sus posiciones y los muestre.
 * Autor: Ángel
 * Fecha: 5/11/25
 */

package Ejercicio7.java;

import java.util.Scanner;

public class ejercicio7 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int P, Q;
		
		System.out.println("Dame el valor de P: ");
		P = teclado.nextInt();
		System.out.println("Dame el valor de Q: ");
		Q = teclado.nextInt();
	
		int[] num = new int[Q];
		
		for (int i = 0; i < Q; i++) {
			if (num[i] <= Q) {
				num[i] = P;
				P ++;
			}
		}
		
		for (int i = 0; i < Q; i++) {
			if (num[i] <= Q) {
			System.out.print(num[i] + " ");
			}
		}
	}
}
