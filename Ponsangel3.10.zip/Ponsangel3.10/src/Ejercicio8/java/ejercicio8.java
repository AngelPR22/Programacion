/*
 * Descripción: Crear array con 100 numeros reales aleatorios entre 0.0 y 0.1, luego pedir al usuario un valor R y mostrar iguales o superior a R.
 * Autor: Ángel
 * Fecha: 7/11/25
 */

package Ejercicio8.java;

import java.util.Scanner;

public class ejercicio8 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		new java.util.Random();
		
		double R;
		Double[] num = new Double[100];

		for (int i = 0; i < 100; i++) {
			double random = Math.random();
			num[i] = random;
		}
		
		do {
		System.out.println("Dame un número real (entre 0.0 y 1.0): ");
		R = teclado.nextDouble(); } 
		while (R < 0.0 || R > 1.0);
		
		System.out.println("Los números mayores o iguales al número introducido son: ");
		
		for (int i = 0; i < 100; i++) {
			if (num[i] >= R) {
				System.out.println(num[i]);
			}
		}
		
	}
	


}
