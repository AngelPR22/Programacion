/*
 * Descripción: Crear array con 100 numeros enteros aleatorios entre 1 y 10, luego pedir valor a N y mostrar en que posiciones del array aparecen
 * Autor: Ángel
 * Fecha: 10/11/25
 */

package Ejercicio9.java;

import java.util.Scanner;

public class ejercicio9 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int N;
		int[] num = new int[100];
		
		for (int i = 0; i < 100; i++) {
			num[i] = (int) (1 + Math.random()*10);
		}
		
		do {
		System.out.println("Dale un valor a N: ");
		N = teclado.nextInt(); 
		} while (N < 0 || N > 10);
		
		for (int i = 0; i < 100; i++) {
			if (num[i] == N) {
				System.out.println("N aparece en las posiciónes " + i + " del array");
			}
		}
	}
}
