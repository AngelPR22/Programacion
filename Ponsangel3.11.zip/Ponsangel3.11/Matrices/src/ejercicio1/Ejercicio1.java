/*
 * Descripción: Crear matriz tamaño 5x5 y almacenar valores del 1 al 25.
 * Autor: Ángel
 * Fecha: 12/11/25
 */

package ejercicio1;

public class Ejercicio1 {

	public static void main(String[] args) {
		
		int[][] matriz = new int [5][5];
		int num = 1;
		
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5;j++) {
				matriz[i][j] = num;
				num++;
			}
		}
		
		
		 System.out.println("Matriz 5x5:");
	        for (int i = 0; i < 5; i++) {
	            for (int j = 0; j < 5; j++) {
	                System.out.printf("%3d ", matriz[i][j]);
	            }
	            System.out.println();
	        }


		
	}

}
