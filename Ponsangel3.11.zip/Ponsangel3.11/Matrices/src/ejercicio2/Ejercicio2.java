/*
 * Descripción: Matriz de 10x10 que sean los valores de las tablas de multiplicar del 1 al 10.
 * Autor: Ángel
 * Fecha: 12/11/25
 */

package ejercicio2;

public class Ejercicio2 {

	public static void main(String[] args) {
		
		int[][] matriz = new int[11][11];
		
		for (int i = 1; i < 11; i++) {
			for (int j = 1; j < 11; j++) {
				matriz[i][j] = i * j;
				System.out.println(i + " x " + j + " = " + matriz[i][j]);
			}
			System.out.println("");
		}
	}

}
