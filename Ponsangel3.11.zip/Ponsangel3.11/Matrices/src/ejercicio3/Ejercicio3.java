/*
 * Descripción: Almacenar matriz de tamaño y valores y mostrar mayores, menores e iguales a cero.
 * Autor: Ángel
 * Fecha: 12/11/25
 */

package ejercicio3;

import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int N, M, num, contador_mayor = 0, contador_menor = 0, contador = 0;
		
		
		System.out.println("Dame el valor de N: ");
		N = teclado.nextInt();
		
		System.out.println("Dame el valor de M: ");
		M = teclado.nextInt();
		
		int[][] matriz = new int[N][M];
		
		System.out.println("Dame el valor de la matriz: ");
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
                System.out.print("Elemento [" + i + "][" + j + "]: ");
                matriz[i][j] = teclado.nextInt();
			}
		}
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				if (matriz[i][j] < 0) {
					contador_menor++;
				} else if (matriz[i][j] > 0) {
					contador_mayor++;
				} else { 
					contador++;
				}
			}
		}
		
		System.out.println("Mayores a cero son: " + contador_mayor + "\nMenores a cero son: " + contador_menor + "\nIguales a cero son: " + contador);
	}
}
