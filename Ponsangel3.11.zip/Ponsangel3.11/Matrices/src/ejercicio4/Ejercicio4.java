/*
 * Descripción: Almacenar notas de 5 alumnos y 5 asignaturas.
 * El usuario introducirá las notas y luego mostrará la nota mínima, máxima y media de cada alumno.
 * Autor: Ángel
 * Fecha: 12/11/25
 */

package ejercicio4;

import java.util.Scanner;

public class Ejercicio4 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        double[][] matriz = new double[4][5]; // 4 alumnos, 5 asignaturas

        // Introducir las notas
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print("Dame la nota del Alumno " + (i + 1) + 
                                 " en la Asignatura " + (j + 1) + ": ");
                matriz[i][j] = teclado.nextDouble();
            }
        }

        // Calcular min, max y media por alumno
        for (int i = 0; i < 4; i++) {
            double suma = 0;
            double min = matriz[i][0];
            double max = matriz[i][0];

            for (int j = 0; j < 5; j++) {
                double nota = matriz[i][j];
                suma += nota;
                if (nota < min) min = nota;
                if (nota > max) max = nota;
            }

            double media = suma / 5;

            System.out.println("\nAlumno " + (i + 1) + ":");
            System.out.println("Nota mínima: " + min);
            System.out.println("Nota máxima: " + max);
            System.out.printf("Nota media: %.2f\n", media);
        }
    }
}

