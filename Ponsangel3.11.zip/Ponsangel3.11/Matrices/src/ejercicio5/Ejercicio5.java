/*
 * Descripción: Registrar sueldos de hombres y mujeres y detectar si existe brecha salarial.
 * El programa pide N personas, su género (0 = varón, 1 = mujer) y su sueldo.
 * Luego calcula y muestra el sueldo medio de cada género.
 * Autor: Ángel
 * Fecha: 12/11/25
 */

package ejercicio5;

import java.util.Scanner;

public class Ejercicio5 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        // Pedimos cuántas personas hay
        System.out.print("Introduce el número de personas: ");
        int n = teclado.nextInt();

        // Creamos una matriz de Nx2: [género, sueldo]
        double[][] datos = new double[n][2];

        // Introducir la información de cada persona
        for (int i = 0; i < n; i++) {
            System.out.println("\nPersona " + (i + 1) + ":");

            System.out.print("Género (0 = varón, 1 = mujer): ");
            datos[i][0] = teclado.nextInt();

            System.out.print("Sueldo: ");
            datos[i][1] = teclado.nextDouble();
        }

        // Variables para cálculos
        double sumaHombres = 0, sumaMujeres = 0;
        int contHombres = 0, contMujeres = 0;

        // Recorrer la matriz y acumular sueldos según género
        for (int i = 0; i < n; i++) {
            if (datos[i][0] == 0) { // Hombre
                sumaHombres += datos[i][1];
                contHombres++;
            } else if (datos[i][0] == 1) { // Mujer
                sumaMujeres += datos[i][1];
                contMujeres++;
            }
        }

        // Calcular medias
        double mediaHombres = (contHombres > 0) ? (sumaHombres / contHombres) : 0;
        double mediaMujeres = (contMujeres > 0) ? (sumaMujeres / contMujeres) : 0;

        // Mostrar resultados
        System.out.println("\n=== RESULTADOS ===");
        System.out.printf("Sueldo medio de hombres: %.2f\n", mediaHombres);
        System.out.printf("Sueldo medio de mujeres: %.2f\n", mediaMujeres);

        // Comprobamos si hay brecha salarial
        if (mediaHombres > mediaMujeres) {
            System.out.println("Existe brecha salarial: los hombres ganan más de media.");
        } else if (mediaMujeres > mediaHombres) {
            System.out.println("Existe brecha salarial: las mujeres ganan más de media.");
        } else {
            System.out.println("No existe brecha salarial: ambos géneros ganan lo mismo de media.");
        }
    }
}
