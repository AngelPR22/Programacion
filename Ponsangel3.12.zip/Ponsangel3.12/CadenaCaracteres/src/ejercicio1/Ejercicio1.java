/*
 * Descripción: Pedir cadena de texto por teclado y mostrarla en lineas distintas.
 * Autor: Ángel
 * Fecha: 12/11/25
 */

package ejercicio1;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		 // Pedir la cadena de texto al usuario
        System.out.print("Introduce una cadena de texto: ");
        String texto = teclado.nextLine();

        // Dividir el texto en palabras separadas por espacios
        String[] palabras = texto.split("\\s+"); // \\s+ significa “uno o más espacios en blanco” (incluye tabulaciones o múltiples espacios).

        // Mostrar cada palabra en una línea distinta
        System.out.println("\nPalabras separadas:");
        for (String palabra : palabras) {
            System.out.println(palabra);
        }
	}

}
