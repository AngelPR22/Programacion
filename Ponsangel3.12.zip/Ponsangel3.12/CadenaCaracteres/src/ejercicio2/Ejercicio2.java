/*
 * Descripción: Pedir dos cadenas de textos y indicar si son iguales, ademas si son iguales sin diferenciar mayusculas y minusculas.
 * Autor: Ángel
 * Fecha: 12/11/25
 */

package ejercicio2;

import java.util.Scanner;

public class Ejercicio2 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduce la primera cadena: ");
        String cadena1 = teclado.nextLine();

        System.out.print("Introduce la segunda cadena: ");
        String cadena2 = teclado.nextLine();

        // Comparación exacta
        if (cadena1.equals(cadena2)) {
            System.out.println("Las cadenas son exactamente iguales.");
        } else {
            System.out.println("Las cadenas NO son exactamente iguales.");
        }

        // Comparación ignorando mayúsculas/minúsculas
        if (cadena1.equalsIgnoreCase(cadena2)) {
            System.out.println("Las cadenas son iguales (ignorando mayúsculas y minúsculas).");
        } else {
            System.out.println("Las cadenas NO son iguales ni siquiera ignorando mayúsculas/minúsculas.");
        }
    }
}
