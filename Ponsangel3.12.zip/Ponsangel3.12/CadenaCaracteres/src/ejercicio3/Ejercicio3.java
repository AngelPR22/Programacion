/*
 * Descripción: Pedir tres cadenas de texto; nombre y dos apellidos. Mostrar en mayusculas las 3 primeras letras de cada uno de ellos.
 * Autor: Ángel
 * Fecha: 13/11/25
 */

package ejercicio3;

import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		String nombre,apellido1, apellido2;
		
		System.out.println("Dame tu nombre: ");
		nombre = teclado.nextLine();
		System.out.println("Dame tu primer apellido: ");
		apellido1 = teclado.nextLine();
		System.out.println("Dame tu segundo apellido: ");
		apellido2 = teclado.nextLine();
		
		// Convierte las tres cadenas texto en mayusculas y agarra solo las tres primeras
		String nombreMayus = nombre.toUpperCase().substring(0, 3);
		String apellido1Mayus = apellido1.toUpperCase().substring(0, 3);
		String apellido2Mayus = apellido2.toUpperCase().substring(0, 3);
		
		System.out.println(nombreMayus + apellido1Mayus + apellido2Mayus);
	}

}
