/*
 * Descripción: Contador de cada tipo de vocales mediante una frase introducida por teclado. no se debe diferenciar entre mayusculas y minusculas.
 * Autor: Ángel
 * Fecha: 13/11/25
 */

package ejercicio4;

import java.util.Scanner;

public class Ejercicio4 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		String frase;
		
		System.out.println("Dame una frase: ");
		frase = teclado.nextLine();
	}

}
